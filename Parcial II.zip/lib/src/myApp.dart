import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class myApp extends StatelessWidget {
  const myApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: Color(0xffe3dcaf),
          body: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  child: Text('Barbería la playa',
                      style: TextStyle(
                          color: Color(0xfffefefe),
                          fontSize: 40,
                          fontFamily: 'Arial',
                          fontWeight: FontWeight.bold)),
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(left: 30),
                ),
                Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.only(left: 40, top: 10, bottom: 15),
                  child: Text("De la playa a tu patio",
                      style: TextStyle(
                          color: Color(0xffffffff),
                          fontSize: 15,
                          fontFamily: 'Arial')),
                ),
                Container(
                    padding: EdgeInsets.only(top: 20),
                    margin: EdgeInsets.only(bottom: 12),
                    child: Column(
                      children: [
                        Container(
                          width: 300,
                          height: 200,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              image: DecorationImage(
                                  image: AssetImage('assets/img/inicio.jpg'),
                                  fit: BoxFit.cover)),
                        )
                      ],
                    )),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top: 15, bottom: 15, left: 25),
                  child: Text('NUESTROS SERVICIOS',
                      style: TextStyle(
                          color: Color(0xffffffff),
                          fontFamily: 'Arial',
                          fontWeight: FontWeight.w300,
                          fontSize: 17)),
                ),
                Container(
                  margin: EdgeInsets.only(left: 25),
                  child: Column(
                    children: [
                      Container(
                        height: 160,
                        width: 230,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                                image: AssetImage('assets/img/cuarta.jpg'),
                                fit: BoxFit.cover)),
                        child: Column(children: [
                          Container(
                            margin: EdgeInsets.only(top: 10, bottom: 5),
                            alignment: Alignment.topCenter,
                          ),
                          Container(
                            padding: EdgeInsets.only(),
                            alignment: Alignment.bottomCenter,
                            child: Column(children: [
                              Text(
                                'CORTES',
                                style: TextStyle(
                                    color: Color(0xffffffff),
                                    fontFamily: 'Arial'),
                              ),
                              Text('ECHA UN VISTAZO',
                                  style: TextStyle(
                                      color: Color(0xffffffff),
                                      fontFamily: 'Arial'))
                            ]),
                          )
                        ]),
                      ),
                      Container(
                        margin: EdgeInsets.only(),
                        height: 160,
                        width: 230,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                                image: AssetImage('assets/img/tercero.jpg'),
                                fit: BoxFit.cover)),
                        child: Column(children: [
                          Container(
                              margin: EdgeInsets.only(top: 10, bottom: 5),
                              alignment: Alignment.topCenter),
                          Container(
                            padding: EdgeInsets.only(),
                            alignment: Alignment.bottomCenter,
                            child: Column(children: [
                              Text(
                                'BARBEROS',
                                style: TextStyle(
                                    color: Colors.white, fontFamily: 'Arial'),
                              )
                            ]),
                          )
                        ]),
                      ),
                      Container(
                        margin: EdgeInsets.only(),
                        height: 160,
                        width: 230,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            image: DecorationImage(
                                image: AssetImage('assets/img/last.jpg'),
                                fit: BoxFit.cover)),
                        child: Column(children: [
                          Container(
                              margin: EdgeInsets.only(top: 10, bottom: 5),
                              alignment: Alignment.topCenter),
                          Container(
                            padding: EdgeInsets.only(),
                            alignment: Alignment.bottomCenter,
                            child: Column(children: [
                              Text(
                                'AGENTA TU CITA',
                                style: TextStyle(
                                    color: Colors.white, fontFamily: 'Arial'),
                              )
                            ]),
                          )
                        ]),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          bottomNavigationBar: BottomNavigationBar(
            items: [
              BottomNavigationBarItem(
                  icon: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15)),
                    height: 40,
                    width: 80,
                    child: Icon(Icons.home_filled, color: Colors.black),
                  ),
                  label: ''),
              BottomNavigationBarItem(
                  icon: Container(
                    decoration: BoxDecoration(
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(15)),
                    height: 40,
                    width: 80,
                    child: Icon(Icons.person, color: Color(0xff000000)),
                  ),
                  label: ''),
              BottomNavigationBarItem(
                  icon: Container(
                    decoration: BoxDecoration(
                        color: Color(0xfff4f4f4),
                        borderRadius: BorderRadius.circular(15)),
                    height: 40,
                    width: 80,
                    child: Icon(Icons.fact_check, color: Color(0xff000000)),
                  ),
                  label: ''),
            ],
            elevation: 0,
            backgroundColor: Colors.transparent,
          )

          /*Row(children: [
          Container(
            margin: EdgeInsets.only(left: 30, bottom: 20, right: 30),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(15)),
            height: 40,
            width: 80,
            child: Icon(Icons.home_filled, color: Colors.black),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20, right: 30),
            decoration: BoxDecoration(
                color: Color(0xff8e8e8e),
                borderRadius: BorderRadius.circular(15)),
            height: 40,
            width: 80,
            child: Icon(Icons.devices, color: Colors.black),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20, right: 30),
            decoration: BoxDecoration(
                color: Color(0xff8e8e8e),
                borderRadius: BorderRadius.circular(15)),
            height: 40,
            width: 80,
            child: Icon(Icons.settings, color: Colors.black),
          )
        ]),*/
          ),
    );
  }
}
